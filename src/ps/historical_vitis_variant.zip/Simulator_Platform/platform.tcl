# 
# Usage: To re-create this platform project launch xsct with below options.
# xsct E:\Code\Vivado\Vivado_2020\ZYNQ\Single_Channel_Simulator\Single_Channel_Simulator_Vitis\Simulator_Platform\platform.tcl
# 
# OR launch xsct and run below command.
# source E:\Code\Vivado\Vivado_2020\ZYNQ\Single_Channel_Simulator\Single_Channel_Simulator_Vitis\Simulator_Platform\platform.tcl
# 
# To create the platform in a different location, modify the -out option of "platform create" command.
# -out option specifies the output directory of the platform project.

platform create -name {Simulator_Platform}\
-hw {E:\Code\Vivado\Vivado_2020\ZYNQ\Single_Channel_Simulator\Top_Module.xsa}\
-proc {ps7_cortexa9_0} -os {standalone} -fsbl-target {psu_cortexa53_0} -out {E:/Code/Vivado/Vivado_2020/ZYNQ/Single_Channel_Simulator/Single_Channel_Simulator_Vitis}

platform write
platform generate -domains 
platform active {Simulator_Platform}
bsp reload
bsp setlib -name lwip211 -ver 1.3
bsp setlib -name xilffs -ver 4.4
bsp write
bsp reload
catch {bsp regenerate}
bsp write
domain active {zynq_fsbl}
bsp reload
bsp reload
domain active {standalone_domain}
bsp reload
bsp reload
domain active {zynq_fsbl}
bsp setlib -name lwip211 -ver 1.3
bsp write
bsp reload
catch {bsp regenerate}
bsp removelib -name lwip211
bsp write
bsp reload
catch {bsp regenerate}
platform generate
domain active {standalone_domain}
bsp reload
bsp write
bsp reload
platform generate -domains 
platform clean
platform config -updatehw {E:/Code/Vivado/Vivado_2020/ZYNQ/Single_Channel_Simulator/Top_Module.xsa}
platform generate
platform config -updatehw {E:/Code/Vivado/Vivado_2020/ZYNQ/Single_Channel_Simulator/Top_Module.xsa}
platform generate -domains 
platform active {Simulator_Platform}
platform config -updatehw {E:/Code/Vivado/Vivado_2020/ZYNQ/Single_Channel_Simulator/Top_Module.xsa}
platform generate -domains 
platform generate -domains zynq_fsbl 
platform generate -domains zynq_fsbl 
platform generate
platform active {Simulator_Platform}
platform config -updatehw {E:/Code/Vivado/Vivado_2020/ZYNQ/Single_Channel_Simulator/Top_Module.xsa}
platform generate
platform active {Simulator_Platform}
platform config -updatehw {E:/Code/Vivado/Vivado_2020/ZYNQ/Single_Channel_Simulator/Top_Module.xsa}
platform generate
platform config -updatehw {E:/Code/Vivado/Vivado_2020/ZYNQ/Single_Channel_Simulator/Top_Module.xsa}
platform generate -domains 
platform active {Simulator_Platform}
platform config -updatehw {E:/Code/Vivado/Vivado_2020/ZYNQ/Single_Channel_Simulator/Top_Module.xsa}
platform generate -domains 
platform config -updatehw {E:/Code/Vivado/Vivado_2020/ZYNQ/Single_Channel_Simulator/Top_Module.xsa}
platform generate -domains 
platform config -updatehw {E:/Code/Vivado/Vivado_2020/ZYNQ/Single_Channel_Simulator/Top_Module.xsa}
platform generate -domains 
platform active {Simulator_Platform}
platform config -updatehw {E:/Code/Vivado/Vivado_2020/ZYNQ/Single_Channel_Simulator/Top_Module.xsa}
platform generate
platform active {Simulator_Platform}
platform config -updatehw {E:/Code/Vivado/Vivado_2020/ZYNQ/Single_Channel_Simulator/Top_Module.xsa}
platform generate -domains 
platform generate -domains 
