#include <string.h>
#include "lwip/udp.h"
#include "xparameters.h"
#include "xil_printf.h"
#include "ad9361/ad9361_api.h"
#include "saw_control.h"

#define UDP_CONN_PORT             4001
#define SAW_UDP_MAX_PACKET        128
#define SAW_UDP_VERSION           0x02

#define SAW_UDP_CMD_CONFIG        0xE0
#define SAW_UDP_CMD_START         0xE1
#define SAW_UDP_CMD_STOP          0xE2
#define SAW_UDP_CMD_STATUS        0xE3

#define SAW_UDP_CONFIG_WORDS      11
#define SAW_UDP_STATUS_WORDS      18

extern int EMMC_Write(void);
extern u32 EMMC_Variable[4];
extern struct ad9361_rf_phy *ad9361_phy;

static struct udp_pcb *pcb;

static u16 read_be16(const u8 *data)
{
    return ((u16)data[0] << 8) | (u16)data[1];
}

static u32 read_be32(const u8 *data)
{
    return ((u32)data[0] << 24) | ((u32)data[1] << 16) |
           ((u32)data[2] << 8) | (u32)data[3];
}

static void write_be16(u8 *data, u16 value)
{
    data[0] = (u8)(value >> 8);
    data[1] = (u8)value;
}

static void write_be32(u8 *data, u32 value)
{
    data[0] = (u8)(value >> 24);
    data[1] = (u8)(value >> 16);
    data[2] = (u8)(value >> 8);
    data[3] = (u8)value;
}

static u32 saw_crc32(const u8 *data, u16 length)
{
    u16 i;
    u8 bit;
    u32 crc = 0xFFFFFFFFUL;

    for (i = 0; i < length; i++) {
        crc ^= data[i];
        for (bit = 0; bit < 8; bit++) {
            crc = (crc >> 1) ^ ((crc & 1UL) ? 0xEDB88320UL : 0UL);
        }
    }
    return ~crc;
}

static void send_udp_bytes(struct udp_pcb *upcb, const ip_addr_t *addr,
                           u16 port, const u8 *data, u16 length)
{
    struct pbuf *reply = pbuf_alloc(PBUF_TRANSPORT, length, PBUF_RAM);

    if (reply == 0) {
        return;
    }
    if (pbuf_take(reply, data, length) == ERR_OK) {
        udp_sendto(upcb, reply, addr, port);
    }
    pbuf_free(reply);
}

static void fill_status_payload(u8 *payload)
{
    SAW_RuntimeStatus runtime;
    u32 values[SAW_UDP_STATUS_WORDS];
    u32 i;

    SAW_GetRuntimeStatus(&runtime);
    values[0] = runtime.pl_status;
    values[1] = runtime.pl_debug;
    values[2] = runtime.current_freq_index;
    values[3] = runtime.config_revision;
    values[4] = runtime.point_count;
    values[5] = g_saw_config.center_freq_hz;
    values[6] = g_saw_config.half_bandwidth_hz;
    values[7] = g_saw_config.step_hz;
    values[8] = g_saw_config.tx_time_us;
    values[9] = g_saw_config.guard1_time_us;
    values[10] = g_saw_config.rx_time_us;
    values[11] = g_saw_config.guard2_time_us;
    values[12] = g_saw_config.coherent_repetitions;
    values[13] = g_saw_config.noncoherent_segments;
    values[14] = g_saw_config.tx_sampling_freq_hz;
    values[15] = g_saw_config.rx_sampling_freq_hz;
    values[16] = runtime.rx_samples_last;
    values[17] = runtime.rx_capture_depth;

    for (i = 0; i < SAW_UDP_STATUS_WORDS; i++) {
        write_be32(payload + (i * 4UL), values[i]);
    }
}

static void send_saw_reply(struct udp_pcb *upcb, const ip_addr_t *addr,
                           u16 port, u8 command, u16 sequence, u16 result)
{
    u8 reply[10 + (SAW_UDP_STATUS_WORDS * 4) + 4];
    const u16 payload_length = SAW_UDP_STATUS_WORDS * 4;
    const u16 crc_offset = 10 + payload_length;

    reply[0] = 0x7F;
    reply[1] = 0x4E;
    reply[2] = SAW_UDP_VERSION;
    reply[3] = command;
    write_be16(reply + 4, sequence);
    write_be16(reply + 6, result);
    write_be16(reply + 8, payload_length);
    fill_status_payload(reply + 10);
    write_be32(reply + crc_offset, saw_crc32(reply, crc_offset));
    send_udp_bytes(upcb, addr, port, reply, crc_offset + 4);
}

static int decode_saw_config(const u8 *payload, u16 length,
                             SAW_Config *config)
{
    u32 *fields = (u32 *)config;
    u32 i;

    if (length != (SAW_UDP_CONFIG_WORDS * 4)) {
        return SAW_CONTROL_ERR_ARGUMENT;
    }
    for (i = 0; i < SAW_UDP_CONFIG_WORDS; i++) {
        fields[i] = read_be32(payload + (i * 4UL));
    }
    return SAW_CONTROL_OK;
}

static void handle_saw_packet(struct udp_pcb *upcb, const ip_addr_t *addr,
                              u16 port, const u8 *packet, u16 length)
{
    u8 command = packet[3];
    u16 sequence = read_be16(packet + 4);
    u16 payload_length = read_be16(packet + 6);
    u16 result = SAW_CONTROL_ERR_ARGUMENT;
    SAW_Config config;
    u32 received_crc;
    u32 calculated_crc;

    if ((payload_length > (SAW_UDP_MAX_PACKET - 12)) ||
        (length != (u16)(8 + payload_length + 4))) {
        send_saw_reply(upcb, addr, port, command, sequence, result);
        return;
    }

    received_crc = read_be32(packet + 8 + payload_length);
    calculated_crc = saw_crc32(packet, 8 + payload_length);
    if (received_crc != calculated_crc) {
        send_saw_reply(upcb, addr, port, command, sequence, result);
        return;
    }

    switch (command) {
    case SAW_UDP_CMD_CONFIG:
        result = decode_saw_config(packet + 8, payload_length, &config);
        if (result == SAW_CONTROL_OK) {
            result = SAW_ApplyConfig(&config);
        }
        break;
    case SAW_UDP_CMD_START:
        result = (payload_length == 0) ? SAW_StartScan() :
                 SAW_CONTROL_ERR_ARGUMENT;
        break;
    case SAW_UDP_CMD_STOP:
        result = (payload_length == 0) ? SAW_StopScan() :
                 SAW_CONTROL_ERR_ARGUMENT;
        break;
    case SAW_UDP_CMD_STATUS:
        result = (payload_length == 0) ? SAW_CONTROL_OK :
                 SAW_CONTROL_ERR_ARGUMENT;
        break;
    default:
        result = SAW_CONTROL_ERR_ARGUMENT;
        break;
    }

    send_saw_reply(upcb, addr, port, command, sequence, result);
}

static void handle_legacy_packet(struct udp_pcb *upcb, const ip_addr_t *addr,
                                 u16 port, const u8 *packet, u16 length)
{
    u8 reply[3] = {0x7F, 0x4E, packet[3]};
    u32 data;
    u32 i;
    u32 *rx_buffer_state = (u32 *)XPAR_BRAM_0_BASEADDR;

    if (length < 8) {
        return;
    }

    if (packet[3] == 0xBA) {
        EMMC_Variable[3] = read_be32(packet + 4) * 100000UL;
        ad9361_set_tx_lo_freq(ad9361_phy, EMMC_Variable[3]);
        EMMC_Write();
    }
    else {
        for (i = 0; (i + 3) < length; i += 4) {
            data = read_be32(packet + i);
            *rx_buffer_state = data;
        }
        if (packet[3] == 0xBB) {
            EMMC_Variable[2] = read_be32(packet + 4);
        }
        else if (packet[3] == 0xBC) {
            EMMC_Variable[1] = read_be32(packet + 4);
        }
        else if (packet[3] == 0xBD) {
            EMMC_Variable[0] = read_be32(packet + 4);
        }
        EMMC_Write();
        *rx_buffer_state = 0xAA5501AA;
    }

    send_udp_bytes(upcb, addr, port, reply, sizeof(reply));
}

static void udp_recv_callback(void *arg, struct udp_pcb *upcb,
                              struct pbuf *p, const ip_addr_t *addr, u16 port)
{
    u8 packet[SAW_UDP_MAX_PACKET];
    u16 length;

    (void)arg;
    if (p == 0) {
        return;
    }

    length = (p->tot_len > SAW_UDP_MAX_PACKET) ?
             SAW_UDP_MAX_PACKET : (u16)p->tot_len;
    pbuf_copy_partial(p, packet, length, 0);

    if ((length >= 4) && (packet[0] == 0xAA) &&
        (packet[1] == 0x55) && (packet[2] == SAW_UDP_VERSION)) {
        if (packet[3] >= SAW_UDP_CMD_CONFIG) {
            if (length >= 12) {
                handle_saw_packet(upcb, addr, port, packet, length);
            }
        }
        else {
            handle_legacy_packet(upcb, addr, port, packet, length);
        }
    }

    pbuf_free(p);
}

void start_application(void)
{
    err_t err;

    pcb = udp_new();
    if (pcb == 0) {
        xil_printf("UDP server: PCB allocation failed\r\n");
        return;
    }

    err = udp_bind(pcb, IP_ADDR_ANY, UDP_CONN_PORT);
    if (err != ERR_OK) {
        xil_printf("UDP server: bind port %d failed, err=%d\r\n",
                   UDP_CONN_PORT, err);
        udp_remove(pcb);
        pcb = 0;
        return;
    }

    udp_recv(pcb, udp_recv_callback, 0);
    xil_printf("SAW UDP control listening on port %d\r\n", UDP_CONN_PORT);
}
