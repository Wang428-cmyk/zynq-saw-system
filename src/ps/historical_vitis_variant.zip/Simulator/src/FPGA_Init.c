#include "xbram_hw.h"
#include "ad9361/ad9361_api.h"
#include "sleep.h"
#include "xil_printf.h"
#include "saw_control.h"

extern int AD9361_Init(void);
extern int EMMC_Init(void);
extern int EMMC_Read(void);
extern void PL_Reset(void);
extern struct ad9361_rf_phy *ad9361_phy;

#define SAW_STATE_CLK_HZ         122880000ULL
#define SAW_DDS_SAMPLE_FREQ_HZ   61440000LL
#define SAW_MAX_POINT_COUNT      127UL
#define SAW_RX_CAPTURE_DEPTH     65536UL
#define SAW_1R1T_FRAME_CYCLES    2UL

#define SAW_REG_CONTROL          0x0004
#define SAW_REG_STATUS           0x0008
#define SAW_REG_TX_SAMPLES       0x000C
#define SAW_REG_GUARD1_SAMPLES   0x0010
#define SAW_REG_RX_SAMPLES       0x0014
#define SAW_REG_POINT_COUNT      0x001C
#define SAW_REG_START_PHASE      0x0020
#define SAW_REG_STEP_PHASE       0x0024
#define SAW_REG_GUARD2_SAMPLES   0x0028
#define SAW_REG_RX_CAPTURED      0x002C
#define SAW_REG_N_COH            0x0030
#define SAW_REG_M_NC             0x0034
#define SAW_REG_DEBUG            0x0038
#define SAW_REG_CURRENT          0x003C

#define SAW_CMD_START            0xAA550201
#define SAW_CMD_STOP             0xAA550203

SAW_Config g_saw_config = {
    915000000UL,
    3000000UL,
    60000UL,
    10UL,
    25UL,
    20UL,
    5UL,
    64UL,
    16UL,
    61440000UL,
    61440000UL
};

uint32_t TX_ATTEN          = 0e3;
uint32_t TX_LO_FREQ        = 915000000UL;
uint32_t RX_LO_FREQ        = 915000000UL;
uint32_t TX_RF_BANDWIDTH   = 6000000UL;
uint32_t RX_RF_BANDWIDTH   = 6000000UL;
uint32_t TX_SAMPLING_FREQ  = SAW_DDS_SAMPLE_FREQ_HZ;
uint32_t RX_SAMPLING_FREQ  = SAW_DDS_SAMPLE_FREQ_HZ;

u32 EMMC_Variable[4];
u32 BRAM_CMD[4] = {0xAA5501BD, 0xAA5501BC, 0xAA5501BB, 0xAA5501AA};

static u32 saw_config_revision;

static u32 SAW_TimeUsToSamples(u32 time_us)
{
    u32 cycles = (u32)((((u64)time_us * SAW_STATE_CLK_HZ) + 999999ULL) /
                       1000000ULL);

    return (cycles + SAW_1R1T_FRAME_CYCLES - 1UL) &
           ~(SAW_1R1T_FRAME_CYCLES - 1UL);
}

static u32 SAW_GetRxSampleCount(const SAW_Config *config)
{
    return SAW_TimeUsToSamples(config->rx_time_us) /
           SAW_1R1T_FRAME_CYCLES;
}

static u32 SAW_FreqHzToPhaseWord(s32 freq_hz)
{
    s64 word = ((s64)freq_hz * (1LL << 32)) / SAW_DDS_SAMPLE_FREQ_HZ;
    return (u32)((s32)word);
}

u32 SAW_GetPointCount(const SAW_Config *config)
{
    if ((config == 0) || (config->step_hz == 0UL)) {
        return 0UL;
    }

    return ((config->half_bandwidth_hz * 2UL) / config->step_hz) + 1UL;
}

static int SAW_ValidateConfig(const SAW_Config *config)
{
    u32 points;

    if (config == 0) {
        return SAW_CONTROL_ERR_ARGUMENT;
    }
    if ((config->center_freq_hz < 70000000UL) ||
        (config->center_freq_hz > 4000000000UL) ||
        (config->half_bandwidth_hz < 100000UL) ||
        (config->half_bandwidth_hz > 28000000UL) ||
        (config->center_freq_hz <= config->half_bandwidth_hz) ||
        (config->step_hz == 0UL) ||
        (config->tx_time_us == 0UL) ||
        (config->rx_time_us == 0UL) ||
        (config->coherent_repetitions == 0UL) ||
        (config->coherent_repetitions > 65535UL) ||
        (config->noncoherent_segments == 0UL) ||
        (config->noncoherent_segments > 65535UL)) {
        return SAW_CONTROL_ERR_RANGE;
    }

    if (SAW_GetRxSampleCount(config) > SAW_RX_CAPTURE_DEPTH) {
        return SAW_CONTROL_ERR_RANGE;
    }

    points = SAW_GetPointCount(config);
    if ((points == 0UL) || (points > SAW_MAX_POINT_COUNT)) {
        return SAW_CONTROL_ERR_RANGE;
    }

    /* The present PL clock wizard is designed for 61.44 MSPS only. */
    if ((config->tx_sampling_freq_hz != 61440000UL) ||
        (config->rx_sampling_freq_hz != 61440000UL)) {
        return SAW_CONTROL_ERR_SAMPLE_RATE;
    }

    return SAW_CONTROL_OK;
}

static void SAW_WritePlConfig(const SAW_Config *config)
{
    u32 base = XPAR_AXI_BRAM_CTRL_0_S_AXI_BASEADDR;

    XBram_WriteReg(base, SAW_REG_TX_SAMPLES,
                   SAW_TimeUsToSamples(config->tx_time_us));
    XBram_WriteReg(base, SAW_REG_GUARD1_SAMPLES,
                   SAW_TimeUsToSamples(config->guard1_time_us));
    XBram_WriteReg(base, SAW_REG_RX_SAMPLES,
                   SAW_TimeUsToSamples(config->rx_time_us));
    XBram_WriteReg(base, SAW_REG_GUARD2_SAMPLES,
                   SAW_TimeUsToSamples(config->guard2_time_us));
    XBram_WriteReg(base, SAW_REG_POINT_COUNT, SAW_GetPointCount(config));
    XBram_WriteReg(base, SAW_REG_START_PHASE,
                   SAW_FreqHzToPhaseWord(-(s32)config->half_bandwidth_hz));
    XBram_WriteReg(base, SAW_REG_STEP_PHASE,
                   SAW_FreqHzToPhaseWord((s32)config->step_hz));
    XBram_WriteReg(base, SAW_REG_N_COH, config->coherent_repetitions);
    XBram_WriteReg(base, SAW_REG_M_NC, config->noncoherent_segments);
}

int SAW_StopScan(void)
{
    u32 timeout;
    u32 base = XPAR_AXI_BRAM_CTRL_0_S_AXI_BASEADDR;

    XBram_WriteReg(base, SAW_REG_CONTROL, SAW_CMD_STOP);
    usleep(100);
    for (timeout = 0; timeout < 1000UL; timeout++) {
        if ((XBram_ReadReg(base, SAW_REG_STATUS) & 0x2UL) == 0UL) {
            return SAW_CONTROL_OK;
        }
        usleep(10);
    }

    return SAW_CONTROL_ERR_STOP_TIMEOUT;
}

int SAW_StartScan(void)
{
    XBram_WriteReg(XPAR_AXI_BRAM_CTRL_0_S_AXI_BASEADDR,
                   SAW_REG_CONTROL, SAW_CMD_START);
    usleep(100);
    return SAW_CONTROL_OK;
}

int SAW_ApplyConfig(const SAW_Config *config)
{
    int ret;
    u32 bandwidth;

    ret = SAW_ValidateConfig(config);
    if (ret != SAW_CONTROL_OK) {
        return ret;
    }

    ret = SAW_StopScan();
    if (ret != SAW_CONTROL_OK) {
        return ret;
    }

    bandwidth = config->half_bandwidth_hz * 2UL;
    if ((ad9361_set_tx_lo_freq(ad9361_phy, config->center_freq_hz) < 0) ||
        (ad9361_set_rx_lo_freq(ad9361_phy, config->center_freq_hz) < 0) ||
        (ad9361_set_tx_rf_bandwidth(ad9361_phy, bandwidth) < 0) ||
        (ad9361_set_rx_rf_bandwidth(ad9361_phy, bandwidth) < 0)) {
        return SAW_CONTROL_ERR_AD9361;
    }

    g_saw_config = *config;
    TX_LO_FREQ = config->center_freq_hz;
    RX_LO_FREQ = config->center_freq_hz;
    TX_RF_BANDWIDTH = bandwidth;
    RX_RF_BANDWIDTH = bandwidth;
    SAW_WritePlConfig(&g_saw_config);
    saw_config_revision++;

    xil_printf("SAW configuration updated; scan remains stopped\r\n");
    return SAW_CONTROL_OK;
}

void SAW_GetRuntimeStatus(SAW_RuntimeStatus *status)
{
    u32 base = XPAR_AXI_BRAM_CTRL_0_S_AXI_BASEADDR;

    if (status == 0) {
        return;
    }
    status->pl_status = XBram_ReadReg(base, SAW_REG_STATUS);
    status->pl_debug = XBram_ReadReg(base, SAW_REG_DEBUG);
    status->current_freq_index = XBram_ReadReg(base, SAW_REG_CURRENT);
    status->config_revision = saw_config_revision;
    status->point_count = SAW_GetPointCount(&g_saw_config);
    status->rx_samples_last = XBram_ReadReg(base, SAW_REG_RX_CAPTURED);
    status->rx_capture_depth = SAW_RX_CAPTURE_DEPTH;
}

static void SAW_PrintConfig(void)
{
    u32 points = SAW_GetPointCount(&g_saw_config);
    u32 start_khz = (g_saw_config.center_freq_hz -
                     g_saw_config.half_bandwidth_hz) / 1000UL;
    u32 stop_khz = (g_saw_config.center_freq_hz +
                    g_saw_config.half_bandwidth_hz) / 1000UL;

    xil_printf("SAW scan: center=%lu kHz range=%lu-%lu kHz step=%lu kHz points=%lu\r\n",
               (unsigned long)(g_saw_config.center_freq_hz / 1000UL),
               (unsigned long)start_khz, (unsigned long)stop_khz,
               (unsigned long)(g_saw_config.step_hz / 1000UL),
               (unsigned long)points);
    xil_printf("SAW frame: tx=%lu us g1=%lu us rx=%lu us g2=%lu us samples=%lu coh=%lu nc=%lu\r\n",
               (unsigned long)g_saw_config.tx_time_us,
               (unsigned long)g_saw_config.guard1_time_us,
               (unsigned long)g_saw_config.rx_time_us,
               (unsigned long)g_saw_config.guard2_time_us,
               (unsigned long)SAW_GetRxSampleCount(&g_saw_config),
               (unsigned long)g_saw_config.coherent_repetitions,
               (unsigned long)g_saw_config.noncoherent_segments);
}

void FPGA_Init(void)
{
    int i;

    TX_LO_FREQ = g_saw_config.center_freq_hz;
    RX_LO_FREQ = g_saw_config.center_freq_hz;
    TX_RF_BANDWIDTH = g_saw_config.half_bandwidth_hz * 2UL;
    RX_RF_BANDWIDTH = g_saw_config.half_bandwidth_hz * 2UL;
    TX_SAMPLING_FREQ = g_saw_config.tx_sampling_freq_hz;
    RX_SAMPLING_FREQ = g_saw_config.rx_sampling_freq_hz;

    if (AD9361_Init() < 0) {
        xil_printf("AD9361 initialization failed\r\n");
        return;
    }

    EMMC_Init();
    PL_Reset();
    EMMC_Read();

    for (i = 0; i < 3; i++) {
        XBram_WriteReg(XPAR_AXI_BRAM_CTRL_0_S_AXI_BASEADDR, 0, BRAM_CMD[i]);
        XBram_WriteReg(XPAR_AXI_BRAM_CTRL_0_S_AXI_BASEADDR, 0, EMMC_Variable[i]);
    }
    XBram_WriteReg(XPAR_AXI_BRAM_CTRL_0_S_AXI_BASEADDR, 0, BRAM_CMD[3]);

    SAW_WritePlConfig(&g_saw_config);
    saw_config_revision = 1UL;
    SAW_StartScan();
    SAW_PrintConfig();
}
