#ifndef SAW_CONTROL_H
#define SAW_CONTROL_H

#include "xil_types.h"

#define SAW_CONTROL_OK                    0
#define SAW_CONTROL_ERR_ARGUMENT          1
#define SAW_CONTROL_ERR_RANGE             2
#define SAW_CONTROL_ERR_SAMPLE_RATE       3
#define SAW_CONTROL_ERR_AD9361            4
#define SAW_CONTROL_ERR_STOP_TIMEOUT      5

typedef struct {
    u32 center_freq_hz;
    u32 half_bandwidth_hz;
    u32 step_hz;
    u32 tx_time_us;
    u32 guard1_time_us;
    u32 rx_time_us;
    u32 guard2_time_us;
    u32 coherent_repetitions;
    u32 noncoherent_segments;
    u32 tx_sampling_freq_hz;
    u32 rx_sampling_freq_hz;
} SAW_Config;

typedef struct {
    u32 pl_status;
    u32 pl_debug;
    u32 current_freq_index;
    u32 config_revision;
    u32 point_count;
    u32 rx_samples_last;
    u32 rx_capture_depth;
} SAW_RuntimeStatus;

extern SAW_Config g_saw_config;

int SAW_ApplyConfig(const SAW_Config *config);
int SAW_StartScan(void);
int SAW_StopScan(void);
void SAW_GetRuntimeStatus(SAW_RuntimeStatus *status);
u32 SAW_GetPointCount(const SAW_Config *config);
void FPGA_Init(void);

#endif
