@echo off
setlocal
cd /d "%~dp0"

set "CODEX_PYTHON=%USERPROFILE%\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe"
if exist "%CODEX_PYTHON%" goto use_codex_python

py -3 --version >nul 2>nul
if not errorlevel 1 goto use_py

python --version >nul 2>nul
if not errorlevel 1 goto use_python

echo Python 3 was not found. Install Python 3 and run this file again.
pause
exit /b 1

:use_py
py -3 server.py --open
goto done

:use_python
python server.py --open
goto done

:use_codex_python
"%CODEX_PYTHON%" server.py --open

:done
if errorlevel 1 pause
