# SAW Browser Control

Run `start_server.bat`, then open `http://127.0.0.1:8080` in a browser. The
bridge uses only the Python standard library and sends UDP to the default board
address `192.168.2.10:4001`.

The launcher first uses the Python runtime bundled with Codex. If that runtime
is unavailable, it falls back to a working `py -3` or `python` installation;
the Windows Store execution alias is ignored because it fails the version test.

## Control flow

1. PS mounts eMMC without formatting it, validates the newest A/B configuration
   record by version, length, range checks and CRC, then falls back to compiled
   defaults if neither copy is valid.
2. PS configures AD9361 and PL and starts scanning automatically. One job is a
   coarse sweep followed, when enabled, by a fine sweep around every detected
   coarse peak (up to four).
3. At the end of a job PS publishes an immutable result snapshot, pushes all
   coarse/fine packets to the subscribed upper computer, and immediately starts
   the next job. No per-round `START` or acknowledgement is required.
4. `CONFIG` validates and applies all 17 scan fields, saves them and the result
   receiver endpoint to eMMC, and automatically starts continuous scanning.
5. `START` is idempotent and enables/resumes continuous scanning. `STOP`
   disables continuous scanning, TX and RX control outputs, but keeps the last
   published result readable.

## SAW UDP v2

Requests use the `AA 55 02` header:

```text
AA 55 02 CMD SEQ_BE16 PAYLOAD_LEN_BE16 PAYLOAD CRC32_BE
```

Control commands are `E0 CONFIG`, `E1 START`, `E2 STOP`, `E3 STATUS`,
`E4 RESULTS`, `E6 FINE_RESULTS`, and `E7 SUBSCRIBE`. CONFIG carries 17
big-endian uint32 fields in the same order as `SAW_Config`. The last six fields
enable/configure fine scan, its LO offset, `coarse_lo_blind_hz`, and
`coarse_lo_guard_hz`. The blind
width is persisted and is used by PS only to exclude the LO region from coarse
peak selection; raw energy values are never masked or rewritten by PS.

`E7 SUBSCRIBE` carries `receiver_port` and `persist` as two big-endian uint32
values. The source IPv4 address plus `receiver_port` becomes the destination for
active result streaming. With `persist=1` the endpoint is committed to the same
A/B eMMC record as the scan configuration.

RESULTS requests carry `start_index` and `requested_points` as two big-endian
uint32 values. The firmware returns at most 127 points per packet. Its payload is
`total_points`, `start_index`, `returned_points`, followed by one big-endian
uint64 energy value per point. PL stops itself exactly after the final point,
then PS copies the complete sweep into a local snapshot. RESULTS reads this PS
snapshot while the next PL sweep may already be running. Point count is always
derived as `bandwidth_hz / step_hz + 1`; bandwidth must be an exact multiple
of step and the count is not fixed at 101. Coarse LO is
`start_freq_hz - coarse_lo_guard_hz`, so the PL scans only positive NCO offsets
from `coarse_lo_guard_hz` through `coarse_lo_guard_hz + bandwidth_hz`.

Fine scanning is orchestrated by PS; PL remains limited to 127 points per
sweep. A fine curve up to 1024 points is split into 127-point PL chunks, merged
in PS, and may still be manually retrieved by E6.

PS actively sends `E8 RESULT_DATA` packets for the coarse curve and every fine
curve, followed by one `E9 RESULT_END`. Each E8 payload starts with 12 uint32
metadata words:

```text
generation, config_revision, scan_type, peak_id, coarse_index,
target_frequency_hz, lo_frequency_hz, start_frequency_hz, step_hz,
total_points, start_index, returned_points
```

The metadata is followed by `returned_points` big-endian uint64 energies. The
upper computer accepts out-of-order chunks and updates the plots only after E9
and every declared chunk form a complete bundle. The default stream destination
port is UDP 4002 and can be changed with `--notify-port`.

When fine scan is enabled, the coarse-plot peak cards and markers use the
`coarse_index` and `target_frequency_hz` selected by PS. Their count and
numbering therefore match the fine-scan curves exactly. The browser-side peak
detector is used only when fine scan is disabled.

## Power display

The browser no longer normalizes every sweep to its largest point. PL now uses
a complex NCO at every configured scan frequency, coherently integrates each RX
window, and accumulates the window energies. The bridge reports detector dBFS:

```text
windows = coherent_repetitions * noncoherent_segments
power_dbfs = 10 * log10(energy / (rx_samples^2 * windows * 2048^2))
power_dbm = power_dbfs + zero_dbfs_input_power_dbm
```

RX2 uses a fixed 20 dB manual gain so the detector level remains repeatable.
Absolute dBm still requires a one-point calibration on the completed board:
inject a known input power and set `zero_dbfs_input_power_dbm` to
`known_input_dbm - measured_peak_dbfs`. This calibration includes connector,
matching-network and analog-path loss.

Responses are:

```text
7F 4E 02 CMD SEQ_BE16 RESULT_BE16 PAYLOAD_LEN_BE16 STATUS_PAYLOAD CRC32_BE
```

The firmware continues to accept the original `BA` through `BD` commands.
