# CLK Constraint
create_clock -period 8.138 -waveform {0.000 4.069} [get_ports clk_in_p]

# Clock Port
# SMART_RADCOM_2021_V1 U2-D: M6/M5 are DATA_CLK_P/N_AD9361.
set_property -dict {PACKAGE_PIN M6 IOSTANDARD LVDS DIFF_TERM 1} [get_ports clk_in_p]
set_property -dict {PACKAGE_PIN M5 IOSTANDARD LVDS DIFF_TERM 1} [get_ports clk_in_n]

# TX port
set_property -dict {PACKAGE_PIN J4 IOSTANDARD LVDS} [get_ports tx_clk_p]
set_property -dict {PACKAGE_PIN J3 IOSTANDARD LVDS} [get_ports tx_clk_n]
set_property -dict {PACKAGE_PIN L3 IOSTANDARD LVDS} [get_ports tx_frame_p]
set_property -dict {PACKAGE_PIN K3 IOSTANDARD LVDS} [get_ports tx_frame_n]
set_property -dict {PACKAGE_PIN H4 IOSTANDARD LVDS} [get_ports {tx_data_p[0]}]
set_property -dict {PACKAGE_PIN H3 IOSTANDARD LVDS} [get_ports {tx_data_n[0]}]
set_property -dict {PACKAGE_PIN G2 IOSTANDARD LVDS} [get_ports {tx_data_p[1]}]
set_property -dict {PACKAGE_PIN F2 IOSTANDARD LVDS} [get_ports {tx_data_n[1]}]
set_property -dict {PACKAGE_PIN F3 IOSTANDARD LVDS} [get_ports {tx_data_p[2]}]
set_property -dict {PACKAGE_PIN E3 IOSTANDARD LVDS} [get_ports {tx_data_n[2]}]
set_property -dict {PACKAGE_PIN E2 IOSTANDARD LVDS} [get_ports {tx_data_p[3]}]
set_property -dict {PACKAGE_PIN E1 IOSTANDARD LVDS} [get_ports {tx_data_n[3]}]
set_property -dict {PACKAGE_PIN D1 IOSTANDARD LVDS} [get_ports {tx_data_p[4]}]
set_property -dict {PACKAGE_PIN C1 IOSTANDARD LVDS} [get_ports {tx_data_n[4]}]
set_property -dict {PACKAGE_PIN K5 IOSTANDARD LVDS} [get_ports {tx_data_p[5]}]
set_property -dict {PACKAGE_PIN J5 IOSTANDARD LVDS} [get_ports {tx_data_n[5]}]

# AD9361 SPI Config
set_property -dict {PACKAGE_PIN G6  IOSTANDARD LVCMOS18 PULLTYPE PULLUP} [get_ports spi_csn ]
set_property -dict {PACKAGE_PIN J11 IOSTANDARD LVCMOS18} [get_ports spi_clk ]
set_property -dict {PACKAGE_PIN F7  IOSTANDARD LVCMOS18} [get_ports spi_mosi]
set_property -dict {PACKAGE_PIN G5  IOSTANDARD LVCMOS18} [get_ports spi_miso]

# AD9361 Reset
set_property -dict {PACKAGE_PIN H7  IOSTANDARD LVCMOS18} [get_ports gpio_resetb]

# AD9361 FDD Independent Control
# ENABLE(G6 on AD9361) is mapped to Force Rx On; TXNRX is Force Tx On.
set_property -dict {PACKAGE_PIN L8 IOSTANDARD LVCMOS18 SLEW FAST} [get_ports ad9361_enable]
set_property -dict {PACKAGE_PIN N7 IOSTANDARD LVCMOS18 SLEW FAST} [get_ports ad9361_txnrx]

# External RF switch controls
# Both outputs follow the PL TX-active signal: TX=High, otherwise=Low.
set_property -dict {PACKAGE_PIN W18 IOSTANDARD LVCMOS33 DRIVE 8 SLEW FAST} [get_ports rf_switch_ctrl_1]
set_property -dict {PACKAGE_PIN Y18 IOSTANDARD LVCMOS33 DRIVE 8 SLEW FAST} [get_ports rf_switch_ctrl_2]

# AD9361 RX digital interface
# SMART_RADCOM_2021_V1 U2-D, Bank 33. DATA_CLK_P/N_AD9361 is constrained
# above as clk_in_p/n and reused internally as the RX sampling clock.
set_property -dict {PACKAGE_PIN J1 IOSTANDARD LVDS DIFF_TERM 1} [get_ports rx_frame_p]
set_property -dict {PACKAGE_PIN H1 IOSTANDARD LVDS DIFF_TERM 1} [get_ports rx_frame_n]
set_property -dict {PACKAGE_PIN M2 IOSTANDARD LVDS DIFF_TERM 1} [get_ports {rx_data_p[0]}]
set_property -dict {PACKAGE_PIN L2 IOSTANDARD LVDS DIFF_TERM 1} [get_ports {rx_data_n[0]}]
set_property -dict {PACKAGE_PIN L5 IOSTANDARD LVDS DIFF_TERM 1} [get_ports {rx_data_p[1]}]
set_property -dict {PACKAGE_PIN L4 IOSTANDARD LVDS DIFF_TERM 1} [get_ports {rx_data_n[1]}]
set_property -dict {PACKAGE_PIN N4 IOSTANDARD LVDS DIFF_TERM 1} [get_ports {rx_data_p[2]}]
set_property -dict {PACKAGE_PIN M4 IOSTANDARD LVDS DIFF_TERM 1} [get_ports {rx_data_n[2]}]
set_property -dict {PACKAGE_PIN N1 IOSTANDARD LVDS DIFF_TERM 1} [get_ports {rx_data_p[3]}]
set_property -dict {PACKAGE_PIN M1 IOSTANDARD LVDS DIFF_TERM 1} [get_ports {rx_data_n[3]}]
set_property -dict {PACKAGE_PIN N3 IOSTANDARD LVDS DIFF_TERM 1} [get_ports {rx_data_p[4]}]
set_property -dict {PACKAGE_PIN N2 IOSTANDARD LVDS DIFF_TERM 1} [get_ports {rx_data_n[4]}]
set_property -dict {PACKAGE_PIN K2 IOSTANDARD LVDS DIFF_TERM 1} [get_ports {rx_data_p[5]}]
set_property -dict {PACKAGE_PIN K1 IOSTANDARD LVDS DIFF_TERM 1} [get_ports {rx_data_n[5]}]
